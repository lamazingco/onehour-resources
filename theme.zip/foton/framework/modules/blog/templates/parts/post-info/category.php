
    <?php the_category('&nbsp'); ?>
