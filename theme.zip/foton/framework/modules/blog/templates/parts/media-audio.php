<?php

foton_mikado_get_module_template_part('templates/parts/image', 'blog', '', $params);
foton_mikado_get_module_template_part('templates/parts/post-type/audio', 'blog', '', $params);