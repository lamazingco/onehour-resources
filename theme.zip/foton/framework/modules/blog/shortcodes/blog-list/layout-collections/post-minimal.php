<li class="mkdf-bl-item mkdf-item-space clearfix">
	<div class="mkdf-bli-inner">
		<div class="mkdf-bli-content">
			<?php foton_mikado_get_module_template_part( 'templates/parts/title', 'blog', '', $params ); ?>
			<?php foton_mikado_get_module_template_part( 'templates/parts/post-info/date', 'blog', '', $params ); ?>
		</div>
	</div>
</li>