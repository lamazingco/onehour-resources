<?php

if ( foton_mikado_visual_composer_installed() ) {
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/visualcomposer/visual-composer-config.php';
}