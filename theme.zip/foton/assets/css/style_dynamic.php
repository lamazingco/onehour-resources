<?php

do_action('foton_mikado_action_style_dynamic');