<svg version="1.1" class="thb-play-02" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="80px" height="80px" viewBox="0 0 80 80" enable-background="new 0 0 80 80" xml:space="preserve">
	<path d="M34.833,51.753c-0.357,0-0.715-0.091-1.037-0.274c-0.659-0.374-1.066-1.073-1.066-1.831V28.192
		c0-0.758,0.407-1.458,1.066-1.832c0.659-0.373,1.469-0.362,2.119,0.027l17.883,10.729c0.633,0.379,1.021,1.064,1.021,1.803
		s-0.389,1.423-1.021,1.803L35.915,51.451C35.582,51.653,35.207,51.753,34.833,51.753z M36.937,31.907v14.027l11.69-7.014
		L36.937,31.907z"></path>
	<circle class="circle1" cx="40" cy="40" r="38"></circle>
	<circle class="circle1 circle2" cx="40" cy="40" r="38"></circle>
</svg>