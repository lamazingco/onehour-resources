<svg class="thb-svg-divider" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 447.5" preserveAspectRatio="none">
<polygon points="0,447.5 600,447.5 600,115.5 0,445.5 "/>
</svg>
